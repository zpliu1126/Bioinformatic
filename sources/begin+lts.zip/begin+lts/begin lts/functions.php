<?php
require get_template_directory() . '/inc/function.php';
// 其它自定义代码加到此行下面